import java.util.GregorianCalendar;

public class Opera 
{
/* Stim ca o opera e caracterizata de 
 * Nume, autor, durata, gen, rating, data lansarii, director, data rularii(show date").
 * Incepem cu clasa asta.
 */
	
	// Zona 1
	private String Name, Author, Genre, Director;
	private int Duration,Rating;
	private GregorianCalendar Release_date,Show_date;
	//Se cere la seminar si la teste ca variabilele globale sa fie private, ca sa poata fi accesate doar din clasa asta(Opera), nu si din alte clase.
	// Sfarsit Zona 1
	

	//Facem un constructor ca sa putem instantia clasa
	Opera(String Name, String Author, int Duration, String Genre, int Rating, GregorianCalendar Release_date, String Director, GregorianCalendar Show_date)
	{
		this.Name=Name;
		this.Author=Author;
		this.Duration=Duration;
		this.Genre=Genre;
		this.Rating = Rating;
		this.Release_date=Release_date;
		this.Show_date=Show_date;
		this.Director=Director;
		//Prin this. ne referim la variabilele declarate in zona 1, adica variabile globale si le dam valorile luate din parametrii constructorului, care au acelasi nume(De asta se foloseste this).
		
	}


	public String getName() {
		return Name;
	}


	public String getDirector() {
		return Director;
	}

	public int getRating() {
		return Rating;
	}


	public String getGenre() {
		return Genre;
	}
}
