
public class Main_Class 
{
	//Pe foaie nu cere o clasa main, dar am facut-o ca sa fie. Nu este nevoie de ea daca nu se cere.
	public static void main(String args[])
	{
		Catalog c1 = new Catalog();
		//imi este lene sa scriu mai mult si nu cere in cerinta :( .
		System.out.println(c1.avg_Rating()); //avand in vedere ca nu sunt opere in catalog, e de asteptat sa returneze 0.
		System.out.print(c1.max_Rating());
	}
}
