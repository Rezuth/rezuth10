
public class Catalog 
{
	private Opera operas[]; //un vector de opere. momentan e gol.
	private int nro; //Numar de opere.
	
	Catalog ()
	{
		operas = new Opera[150]; //150 e un numar ales la intamplare, din moment ce nu se specifica numarul maxim de opere. De obicei orice e peste 50 e ok pentru profesori.
		nro = 0; //incepem cu 0 opere.
	}
	public void add_opera(Opera a)
	{
		operas[nro] = a; //bagam opera din parametru in vectorul cu opere.
		nro++; //avem cu o opera in plus in catalog.
	}
	public void add_opera_array(Opera[] a)
	{
		int j=0;
		for(int i=nro;i<nro+a.length;i++)
		{
			operas[i]=a[j];
			j++;
		}
		nro=nro+a.length; 
	}
	
	public boolean remove_opera(String Name, String Director)
	{
		for(int i=0;i<nro;i++)
		{
			if(operas[i].getName()==Name && operas[i].getDirector()==Director)
			{
				remover(i);
				return true;
			}
		}
		return false; //nu am gasit opera.
	}
	
	public void remover(int pos) // il folosim ca sa stergem un element de pe o pozitie.
	{
		if(nro==1)
		{
			nro--;
		}
		else
		{
			for(int i=pos;i<nro-1;i++)
				operas[i]=operas[i+1];
			nro--;
		}
		
	}
	public Opera[] filter_Genre(String Genre)
	{
		int nre=0;//nr elements;
		for(int i=0;i<nro;i++)
		{
			if(operas[i].getGenre()==Genre)
				nre++;
		}
		if(nre==0) return null;
		else
		{
			int ce=0;//current element
			Opera [] found = new Opera[nre];
			for(int i=0;i<nro;i++)
			{
				if(operas[i].getGenre()==Genre)
				{
					found [ce]=operas[i];
					ce++;
				}
			}
			return found;
		}
	}
	public Opera max_Rating()
	{
		int maxr=0; //nu stim ratingul maxim. incepem de la 0.
		int maxindex=-1; //nu cunoastem pe ce pozitie se afla opera cu rating maxim.
		for(int i=0;i<nro;i++)
		{
			if(operas[i].getRating()>maxr)
			{
				maxr=operas[i].getRating();
				maxindex=i;
			}
		}
		if(maxindex!=-1) return operas[maxindex];
		else return null;
	}
	double avg_Rating() //o sa returnam o medie, deci sunt sanse sa fie numar real, nu doar intreg.
	{
		double avg=0.0;
		for(int i=0;i<nro;i++)
			avg=avg+operas[i].getRating();
		if(nro!=0) 
			avg=avg/nro; //ar fi o idee proasta sa incercam sa impartim la 0
		return avg;
	}
}
