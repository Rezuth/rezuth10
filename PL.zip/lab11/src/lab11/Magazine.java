package lab11;

public class Magazine extends Publication
{
	private int volume;
	private int year;
	public Magazine(String name,String author, double price, int id, int volume, int year)
	{
		super(name,author, price, id);
		this.volume=volume;
		this.year=year;
	}
	public int getVolume() {
		return volume;
	}
	public int getYear() {
		return year;
	}
	public String toString()
	{
		return super.getId()+ "\t"+"M\t"+super.getName()+"\t" +super.getAuthor()+ "\t" + super.getPrice() + "\t" + volume + "\t" + year;
	}

}
