package lab11;

public class Book extends Publication 
{
	private int nrPages;
	private String ISBN;
	public Book(String name,String author, double price, int id, int nrPages, String ISBN)
	{
		super(name,author, price, id);
		this.nrPages=nrPages;
		this.ISBN=ISBN;
	}
	public int getNrPages() {
		return nrPages;
	}
	public String getISBN() {
		return ISBN;
	}
	public String toString()
	{
		return super.getId()+ "\t"+"B\t"+super.getName()+"\t"+super.getAuthor()+ "\t" + super.getPrice() + "\t" + nrPages + "\t" + ISBN;
	}
}
