package lab11;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Library {

	File file;
	Publication[] publications = new Publication[100];
	int nrp;
	Library(File file)
	{
		this.file=file;
		nrp=0;
		
	}
	void add(Publication p)
	{
		publications[nrp]=p;
		nrp++;
	}
	boolean remove(int id)
	{
		int i=0;
		boolean found=false;
		while(i<nrp && found==false)
		{
			if(publications[i].getId()==id)
			{
				found=true;
			}
			if(found==false) i++;
		}
		if (found != false)
		{
			for(;i<nrp-1;i++)
				publications[i]=publications[i+1];
			nrp--;
		}
		return found;
	}
	void listAll()
	{
		int i;
		for(i=0;i<nrp;i++)
		{
			System.out.println(publications[i].toString());
		}
	}
	void load()
	{
		
		Scanner reader = null; //scanner declaration
		try
		{
			reader = new Scanner(file); //we bind the scanner to a file
			String placeholder = "bau"; //initialising placeholder with a random string
			while (placeholder!=null) //while we're not at the end of file
			{
				if (reader.hasNext()) //if we're not at the end of file
				{
					placeholder = reader.nextLine(); //we load a new word in the placeholder
					//System.out.println(placeholder);
					if(placeholder!=null) 
					{
						
						String[] ph = placeholder.split("\t");
						//for(j=0;j<ph.length;j++) 
							//System.out.println(ph[j]);
						if (ph[1].equals("B")) 
						{
							///it's a book
							add(new Book(ph[2],ph[3],Double.parseDouble(ph[5]),Integer.parseInt(ph[0]),Integer.parseInt(ph[5]), ph[6]));
							
						}
						else
						{
							///it's a magazine
							add(new Magazine(ph[2],ph[3],Double.parseDouble(ph[5]),Integer.parseInt(ph[0]),Integer.parseInt(ph[5]), Integer.parseInt(ph[6])));
						}
						
					}
				}
				else placeholder=null;
				
			}
			reader.close();
		}
		catch (FileNotFoundException e){}
	}
	void save()
	{
		FileWriter writer;
		try 
		{
			writer = new FileWriter(file);
			int i;
			for(i=0;i<nrp;i++)
			{
				writer.write(publications[i].toString()+"\n");
			}
			writer.flush();
			writer.close();
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
