package lab11;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MainClass {
	public static void main(String args[])
	{
		File input = new File(System.getProperty("user.dir") + "/input.txt"); //the file
		Library l1 = new Library(input);
		l1.load();
		Publication p1 = new Book("Bobby's coding adventure","Bogdan Mihai",35.9,1,155,"00998383");
		Publication p2 = new Book("Bob's coding adventure","Bogdan Mihai",35.9,2,155,"00998383");
		
		
		l1.listAll();
		System.out.println("\nAdding new book:");
		l1.add(p1);
		l1.add(p2);
		l1.listAll();
		l1.save();
		
		
		
	}
}
