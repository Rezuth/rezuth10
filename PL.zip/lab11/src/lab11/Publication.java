package lab11;

public abstract class Publication {
	private String name;
	private String author;
	private double price;
	private int id;
	public Publication(String name,String author, double price, int id)
	{
		this.name=name;
		this.author=author;
		this.price=price;
		this.id=id;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getAuthor() {
		return author;
	}
	public double getPrice() {
		return price;
	}
	
	
}
