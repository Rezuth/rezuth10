
public class Company
{
	String name;
	Company(String name)
	{
		this.name = name;
	}
	
}
