
public class Portfolio 
{
	Share shares[];
	int noShares=0;
	Portfolio()
	{
		shares = new Share[100];
	}
	void addShare(Share s)
	{
		shares[noShares] = s;
		noShares++;
	}
	int computeSum()
	{
		int sum=0;
		for(int i=0; i<noShares;i++)
		{
			sum+=shares[i].value;
		}
		return sum;
	}

}
