
public class Share 
{
	double value;
	Company company;
	Share (double value, Company company)
	{
		this.value = value;
		this.company = company;
	}
	
}
