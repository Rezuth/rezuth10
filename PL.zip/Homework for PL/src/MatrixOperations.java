import java.util.Scanner;

public class MatrixOperations 
{

	public static void main(String[] args)
	{
		Scanner reader = new Scanner(System.in); //Scanner that reads from KB
		int n,m;
		System.out.println("Dimension of the matrixes (X): ");
		n = reader.nextInt();
		System.out.println("Dimension of the matrixes (Y): ");
		m = reader.nextInt();
		//read dimensions - declaring matrixes and preparing for reading;
		double[][] a = new double[n][m];
		double[][] b = new double[n][m];
		
		int i,j;
		//Starting to read;
		
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
			{
				System.out.print("a[" + i + "][" + j + "]: ");
				a[i][j]=reader.nextDouble();
			}
		//read first matrix
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
			{
				System.out.print("b[" + i + "][" + j + "]: ");
				b[i][j]=reader.nextDouble();
			}
		//read second matrix and preparing to add matrixes;
		double[][] c = matrixAdd(a,b);//Will be sum of a and b;
		System.out.println("Added matrixes:");
		for(i=0;i<n;i++)
		{
			for(j=0;j<m;j++) System.out.print(c[i][j]+ " ");
			System.out.println();
		}
		System.out.println("Sum of the diagonal of the first matrix: " + matrixDiagSum(a));
		System.out.println("Sum of the diagonal of the second matrix: " + matrixDiagSum(b));
		System.out.println("Sum of the diagonal of the sum of matrixes: " + matrixDiagSum(c));
	}
	public static double[][] matrixAdd(double m1[][],double m2[][])
	{
		int n=m1.length,m=m1[0].length; //Assuming that m1 and m2 have the same dimensions
		double[][]m3 = new double[n][m];
		int i,j;
		for(i=0;i<n;i++)
			for(j=0;j<m;j++)
			{
				m3[i][j]=m1[i][j]+m2[i][j];
			}
		return m3;
	}
	public static double matrixDiagSum(double m1[][])
	{
		int i;
		double sum=0.0;
		for(i=0;i<m1.length;i++)
			sum+=m1[i][i];
		return sum;
	}
}
