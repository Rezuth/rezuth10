//MBM
public class HW2_EX2 
{
	public static void main(String[] args)
	{
		int a,b;
		a= Integer.parseInt(args[0]);
		b= Integer.parseInt(args[1]);
		System.out.println("Sum: " + (a+b));
		System.out.println("A-B: " + (a-b));
		System.out.println("B-A: " + (b-a));
		System.out.println("A/B: " + ((double)a)/b);
		System.out.println("B/A: " + ((double)b)/a);
		System.out.println("Arithmetic mean: " + (((double)a)+b)/2);
		if(a>b) 
		{
			System.out.println("Max: " + a);
			System.out.println("Min: " + b);
		}
		else
		{
			System.out.println("Max: " + b);
			System.out.println("Min: " + a);
		}
	}
	//End
}
