import java.util.Scanner;

public class Distance 
{
	
	public static void main(String[] args)
	{
		class point
		{
			int x=0,y=0;
		}
		
		point p1 = new point(); //Point 1
		point p2 = new point(); //Point 2
		
		Scanner reader = new Scanner(System.in); //Scanner that reads from KB
		//Reading point 1 data
		System.out.println("X1" + ": ");
		p1.x = reader.nextInt(); 		
		System.out.println("Y1" + ": ");
		p1.y = reader.nextInt(); 
		//Reading point 2 data
		System.out.println("X2" + ": ");
		p2.x = reader.nextInt();
		System.out.println("Y2" + ": ");
		p2.y = reader.nextInt();
		//Displaying Distance
		System.out.println("The distance between the points is " + distance(p1.x,p1.y,p2.x,p2.y));
	}
	public static double distance(double x1, double y1, double x2, double y2)
	{
		
		return Math.sqrt( (x1-x2) * (x1-x2) + (y1-y2) * (y1-y2) ); //Computing distance
	}

}
