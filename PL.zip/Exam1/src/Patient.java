
public class Patient
{
private String name;
private int age;
String CNP;
	Patient(String name, int age, String CNP)
	{
		this.name = name;
		this.age = age;
		this.CNP = CNP;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public String getCNP() {
		return CNP;
	}
	
}
