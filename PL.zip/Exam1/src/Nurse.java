
public class Nurse extends CareProvider
{
	Nurse()
	{
		
	}
	@Override
	public double computeSalary() {
		// TODO Auto-generated method stub
		return 0; ///Salary unknown...
	}

}
