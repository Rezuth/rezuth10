
public class Doctor extends CareProvider
{
	Doctor()
	{
		
	}
	@Override
	public double computeSalary() {
		// TODO Auto-generated method stub
		return 50 * getNoPatients();
	}

}
