
public abstract class CareProvider 
{
	private Patient[] patients;
	private int noPatients;
	public int getNoPatients() {
		return noPatients;
	}
	CareProvider()
	{
		noPatients=0;
		patients = new Patient[100];
	}
	public void addPatient(Patient p)
	{
		patients[noPatients] = p;
		noPatients++;
	}
	public String getOldestPatient()
	{
		int maxage=0;
		int maxindex=-1;
		for(int i=0;i<=noPatients;i++)
		{
			if(maxage<patients[i].getAge())
			{
				maxage=patients[i].getAge();
				maxindex=i;
			}
		}
		return patients[maxindex].getName();
	}
	public abstract double computeSalary();
}
