import java.util.Scanner;
import java.util.Random;
import java.io.*;
public class ex2 {
	public static int randInt(int min, int max) {

	    // NOTE: This will (intentionally) not run as written so that folks
	    // copy-pasting have to think about how to initialize their
	    // Random instance.  Initialization of the Random instance is outside
	    // the main scope of the question, but some decent options are to have
	    // a field that is initialized once and then re-used as needed or to
	    // use ThreadLocalRandom (if using at least Java 1.7).
	    Random rnjesus= new Random();

	    // nextInt is normally exclusive of the top value,
	    // so add 1 to make it inclusive
	    int randomNum = rnjesus.nextInt((max - min) + 1) + min;

	    return randomNum;
	}
	public static void main(String args[]) throws FileNotFoundException
	{
		String []words=new String[9000];
		boolean found;
		int ce=0; ///current element;
		int i=0;
		//int []enc =new int [9000]; ///number of time we encountered x string
		File file = new File(System.getProperty("user.dir") + "/basicWordsinEnglish.txt");
		Scanner reader = null;
		try
		{
			reader = new Scanner(file);
			String placeholder = "bau";
			while (placeholder!=null)
			{
				if (reader.hasNext())
				{
					placeholder = reader.nextLine();
					if(placeholder!=null)
					{
						found=false;
						i=0;
						int fi=0;
						while(i<ce && found==false)
						{
							//System.out.println(placeholder + " - " + words[i]);
							if(placeholder.equals(words[i]))
								{
									
									found=true;
									fi=i;							
								}
							 i++;
						}
						if(found==true) 
							{//enc[fi]++;
							
							
							}
						else
						{		
							words[ce]=placeholder;
							//enc[ce]=1;
							ce++;
						}
					}
				}
				else placeholder=null;
				
			}
			reader.close();
		}
		finally
		{
			//do nothing		
		}	
		try{
		    PrintWriter writer = new PrintWriter("ResultEx2.txt", "UTF-8");
		    
		    for(i=0;i<1000;i++)
			{
				int a=randInt(0,ce-1);
				//if(a<0) a=-a;
				
				//System.out.println("Current word" + i); //debugging purposes
				if(i==0) writer.print(words[a].substring(0, 1).toUpperCase() + words[a].substring(1, words[a].length()) + " ");
				else writer.print(words[a] + " ");
				
				//writer.flush(); //no need to flush that often.
				//if(i%22==0 && i!=0) System.out.println();
			}
		    
			writer.println(".");
		    writer.close();
		} catch (IOException e) {
		   // can't open write file or make main thread sleep.
		}
		
		return;
	}
	
}
