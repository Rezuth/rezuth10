import java.util.Scanner;
import java.io.*;
public class ex1 {
	public static void main(String args[]) throws FileNotFoundException
	{
		String []words=new String[9000];
		boolean found;
		int ce=0; ///current element;
		int i=0; //counter for words
		int []enc =new int [9000]; ///number of time we encountered x string
		File file = new File(System.getProperty("user.dir") + "/basicWordsinEnglish.txt"); //the file
		Scanner reader = null; //scanner declaration
		try
		{
			reader = new Scanner(file); //we bind the scanner to a file
			String placeholder = "bau"; //Initializing placeholder with a random string
			while (placeholder!=null) //while we're not at the end of file
			{
				if (reader.hasNext()) //if we're not at the end of file
				{
					placeholder = reader.nextLine(); //we load a new word in the placeholder
					if(placeholder!=null) 
					{
						found=false;
						i=0;
						int fi=0;
						while(i<ce && found==false) //we search if the read word already exists in the word-list
						{
							if(placeholder.equals(words[i]))
								{
									
									found=true;
									fi=i;							
								}
							 i++;
						}
						if(found==true) 
							{enc[fi]++; 
							
							
							}
						else
						{		
							words[ce]=placeholder;
							enc[ce]=1;
							ce++;
						}
					}
				}
				else placeholder=null;
				
			}
			reader.close();
		}
		finally
		{
					
		}	
		try{
		    PrintWriter writer = new PrintWriter("ResultEx1.txt", "UTF-8");
		    for(i=0;i<ce;i++)
			{
				writer.println(words[i] + " - " + enc[i]);
			}
		    writer.close();
		} catch (IOException e) {
		   // can't open write file. bummer
		}
		
		return;
	}
	
}
