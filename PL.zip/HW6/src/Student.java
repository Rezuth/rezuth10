
public class Student
{
	String name;
	int tpoints=0; ///total points
	int nmarks=0; ///number of marks
	Student(String name)
	{
		this.name = name;
	}
	String getName()
	{
		return name;
	}
	void addExam(int mark)
	{
		tpoints+=mark;
		nmarks+=1;
	}
	int getTotal()
	{
		return tpoints;
	}
	double getMeanMark()
	{
		return ((double)tpoints)/nmarks;
	}
}
