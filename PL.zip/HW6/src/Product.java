public class Product
{
	String name;
	double price;
	Product(String name, double price)
	{
		this.name = name;
		this.price = price;
	}
	void displayProduct()
	{
		System.out.println(name + " - " + price +" ROL");
	}
	double getPrice()
	{
		return price;
	}
	void setPrice(double price)
	{
		this.price = price;
	}
	double getPriceInRon()
	{
		return price/10000;
	}
	void setPriceInRON(double price)
	{
		this.price=price*10000;
	}
}
