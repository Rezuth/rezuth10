
public class Point extends Form {
	int x,y;
	Point(int a, int b)
	{
		x = a;
		y = b;
	}
	Point()
	{

	}
	void setPoint(int a,int b)
	{
		x=a;
		y=b;
	}
	public String toString()
	{
		return x+" "	+y;
	}
	
	double computeArea()
	{
		return 0.0;
	}
	double computeVolume()
	{
		return 0.0;
	}
}
