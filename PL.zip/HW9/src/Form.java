
public abstract class Form
{
	Form()
	{
		
	}
	double computeArea()
	{
		return 0.0;
	}
	double computeVolume()
	{
		return 0.0;
	}
}
