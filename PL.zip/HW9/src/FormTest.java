
public class FormTest 
{
	public static void main(String args[])
	{
		Point a1 = new Point(5,5);
		Circle b1 = new Circle(10,10,10);
		Cylinder c1 = new Cylinder (30,10,20,20);
		System.out.println(a1.toString());
		System.out.println(b1.toString());
		System.out.println(c1.toString());
	}
}
