
public class Cylinder extends Circle
{
	int height;
	int radius;
	int x,y;
	Cylinder()
	{
		
	}
	Cylinder(int h, int r, int a, int b)
	{
		super(r,a,b);
		height = h;
		radius = r;
		x = a;
		y = b;
	}
	void setPoint(int a,int b)
	{
		x=a;
		y=b;
	}
	void setRadius(int r)
	{
		radius = r;
	}
	void setHeight(int h)
	{
		height =h;
	}
	public String toString()
	{
		return height + " " + radius+ " " + x + " " + y;
	}
	
	double computeArea()
	{
		return (2*Pi.value*radius*radius)+height*(2*radius*Pi.value);
	}
	double computeVolume()
	{
		return Pi.value*radius*radius*height;
	}
}
