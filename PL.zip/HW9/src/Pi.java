
public class Pi {

	public static final double value = 3.141592;
}
