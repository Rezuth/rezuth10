
public class Circle extends Point 
{
	int radius;
	int x,y;
	Circle()
	{
		
	}
	Circle(int r, int a, int b)
	{
		super(a,b);
		radius = r;
		x=a;
		y=b;
	}
	void setPoint(int a,int b)
	{
		x=a;
		y=b;
	}
	void setRadius(int r)
	{
		radius = r;
	}
	public String toString()
	{
		return radius+ " " + x + " " + y;
	}
	
	double computeArea()
	{
		return Pi.value*radius*radius;
	}
	double computeVolume()
	{
		return 0.0;
	}
}
