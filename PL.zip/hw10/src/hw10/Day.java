package hw10;

public class Day 
{
	///date, high temp, low temp, precipitations, and snow
	int ht,lt,prec,sn;
	Day(int ht, int lt, int prec, int sn)
	{
		this.ht = ht;
		this.lt=lt;
		this.prec=prec;
		this.sn=sn;
		//System.out.println("Day: " + ht + " " + lt + " " + prec + " " + sn);
	}
	public int getHt() {
		return ht;
	}
	public void setHt(int ht) {
		this.ht = ht;
	}
	public int getLt() {
		return lt;
	}
	public void setLt(int lt) {
		this.lt = lt;
	}
	public int getPrec() {
		return prec;
	}
	public void setPrec(int prec) {
		this.prec = prec;
	}
	public int getSn() {
		return sn;
	}
	public void setSn(int sn) {
		this.sn = sn;
	}
}
