package hw10;

public class Weatherstat 
{
	int nrd=0;
	Day[] day = new Day [33];
	Weatherstat ()
	{
	}
	void adday(int d, int ht, int lt, int prec, int sn)
	{
		day[d]= new Day(ht,lt,prec,sn);
		if(d>nrd) nrd = d;
	}
	double Get_Average_Snow()
	{
		double avg=0;
		for(int i = 1; i<=nrd;i++)
		{
			if(day[i]!=null) avg+=day[i].getSn();
		}
			
		avg=avg/nrd;
		return avg;
	}
	double Get_Average_Prec()
	{
		double avg=0;
		for(int i = 1; i<=nrd;i++)
		{
			if(day[i]!=null) avg+=day[i].getPrec();
		}
			
		avg=avg/nrd;
		return avg;
	}
	int Get_Lo_Temp()
	{
		int mintemp=2000;
		for(int i = 1; i<=nrd;i++)
		{
			if(day[i]!=null) if(day[i].lt<mintemp) mintemp=day[i].lt;
		}
		return mintemp;
	}
	int Get_Hi_Temp()
	{
		int maxtemp=-2000;
		for(int i = 1; i<=nrd;i++)
		{
			if(day[i]!=null) if(day[i].lt>maxtemp) maxtemp=day[i].ht;
		}
		return maxtemp;
	}
}
