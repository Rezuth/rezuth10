package hw10;
import java.util.Scanner;

import java.io.*;

public class Mainprog 
{	
	static double toCelsius(int TempFahrenheit)
	{
		return Math.round(((TempFahrenheit - 32)/1.8) * 100.0) / 100.0; 
	}
	public static void main (String args[]) throws FileNotFoundException
	{
		Weatherstat[][] stat = new Weatherstat[13][3000];
		int startyear=0;
		int endyear=0;
		File file = new File(System.getProperty("user.dir") + "/weather.txt"); //the file
		Scanner reader = null; //scanner declaration
		try
		{
			reader = new Scanner(file); //we bind the scanner to a file
			String placeholder = "bau"; //initialising placeholder with a random string
			while (placeholder!=null) //while we're not at the end of file
			{
				if (reader.hasNext()) //if we're not at the end of file
				{
					placeholder = reader.nextLine(); //we load a new word in the placeholder
					//System.out.println(placeholder);
					if(placeholder!=null) 
					{
						
						String[] ph = placeholder.split("\t");
						if(startyear==0) startyear = Integer.parseInt(ph[2]);
						endyear = Integer.parseInt(ph[2]);
						stat[Integer.parseInt(ph[0])][Integer.parseInt(ph[2])] = new Weatherstat();
						stat[Integer.parseInt(ph[0])][Integer.parseInt(ph[2])].adday(Integer.parseInt(ph[1]),Integer.parseInt(ph[3]),Integer.parseInt(ph[4]),Integer.parseInt(ph[5]),Integer.parseInt(ph[6]));
						
						
						
						//for(j=0;j<ph.length;j++) 
							//System.out.println(ph[j]);
						/*
						if (ph[1].equals("B")) 
						{
							///it's a book
							add(new Book(ph[2],ph[3],Double.parseDouble(ph[5]),Integer.parseInt(ph[0]),Integer.parseInt(ph[5]), ph[6]));
							
						}
						else
						{
							///it's a magazine
							add(new Magazine(ph[2],ph[3],Double.parseDouble(ph[5]),Integer.parseInt(ph[0]),Integer.parseInt(ph[5]), Integer.parseInt(ph[6])));
						}
						*/
					}
				}
				else placeholder=null;
				
			}
			reader.close();
		}
		finally
		{
			//empty statement
		}
		System.out.println("Year | Avg_Prec | Avg_Sn");
		for(int i = startyear; i<=endyear;i++)
		{
			double prec_year_avg=0.0;
			double sn_year_avg=0.0;
			for(int j=1;j<=12;j++)
			{
				prec_year_avg+=stat[j][i].Get_Average_Prec();
				sn_year_avg+=stat[j][i].Get_Average_Snow();
			}
			prec_year_avg=prec_year_avg/12;
			sn_year_avg=sn_year_avg/12;
			System.out.println(i + " | " + prec_year_avg + " | " + sn_year_avg);
		}
		reader = new Scanner(System.in);
		int syear,smnt; ///selected year, selected month;
		smnt = reader.nextInt();
		syear = reader.nextInt();
		reader.close();
		if(smnt<=12 && smnt >=0 && syear>=startyear && syear <=endyear && stat[smnt][syear]!=null )
		{
			System.out.println("Lowest temp: " + toCelsius(stat[smnt][syear].Get_Lo_Temp()));
			System.out.println("Highest temp: " + toCelsius(stat[smnt][syear].Get_Hi_Temp()));
		}
		else
		{
			System.out.println("The selected date doesn't exist in the database.");
		}
		
	}
}
