import numpy as np

class DNA:
    _atoms = ['A', 'C', 'G', 'T']
    _bits = {'A': 0, 'C': 1, 'G': 2, 'T': 3}
    _comb = ['AA', 'AC', 'AG', 'AT', 'CC', 'CA', 'CG', 'CT', 'GG', 'GA', 'GC', 'GT', 'TT', 'TA', 'TC', 'TG']
    _values = {'AA': 0, 'AC': 0, 'AG': 0, 'AT': 0, 'CC': 0, 'CA': 0, 'CG': 0, 'CT': 0, 'GG': 0, 'GA': 0, 'GC': 0,
               'GT': 0, 'TT': 0, 'TA': 0, 'TC': 0, 'TG': 0}
    _atomValues = {'A': 0, 'C': 0, 'G': 0, 'T': 0}



    def _init__(self, size=None):
        if size is None:
            self._size = 30
            self._model1 = ""
            self._model2 = ""

    def add_model1(self, model):
        self._model1 = model

    def add_model2(self, model):
        self._model2 = model

    def analyze(self, model):
        for index in range(len(model) - 1):
            item = ""
            item = model[index] + model[index + 1]
            if item in self._comb:
                value = self._values.get(item)
                self._values.update({item: value + 1})
        for bit in model:
            value = self._atomValues.get(bit)
            self._atomValues.update({bit: value + 1})

    def create_matrix(self, model):
        self.analyze(model)
        a_row = np.array([self._values.get('AA'), self._values.get('AC'), self._values.get('AG'), self._values.get('AT')])
        c_row = np.array([self._values.get('CA'), self._values.get('CC'), self._values.get('CG'), self._values.get('CT')])
        g_row = np.array([self._values.get('GA'), self._values.get('GC'), self._values.get('GG'), self._values.get('GT')])
        t_row = np.array([self._values.get('TA'), self._values.get('TC'), self._values.get('TG'), self._values.get('TT')])
        a_row = a_row / self._atomValues.get('A')
        c_row = c_row / self._atomValues.get('C')
        g_row = g_row / self._atomValues.get('G')
        t_row = t_row / self._atomValues.get('T')
        list =[]
        list.append(a_row)
        list.append(c_row)
        list.append(g_row)
        list.append(t_row)
        list = np.array(list)
        list = np.around(list, 3)
        print(list)




if __name__ == "__main__":
    print('Running........')
    dna = DNA()
    model = 'ATCGATTCGATATCATACACGTAT'
    model1 = 'CTCGACTAGTATGAAGTCCACGCTTG'
    dna.create_matrix(model)
    dna.create_matrix(model1)

