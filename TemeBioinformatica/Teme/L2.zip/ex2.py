import itertools

s='TACGTGCGCGCGAGCTATCTACTGACTTACGACTAGTGTAGCTGCATCATCGATCGA'

bases = ['A', 'C', 'G', 'T']

dinucleotides = [e[0] + '' + e[1] for e in list(itertools.combinations(bases, 2))]
trinucleotides = [e[0] + '' + e[1] + e[2] for e in list(itertools.combinations(bases, 3))]

for dinucleotide in dinucleotides:
    print('Percentage for ', dinucleotide, ':', (s.count(dinucleotide) / len(s) * 100))
    
for trinucleotide in trinucleotides:
    print('Percentage for ', trinucleotide, ':', (s.count(trinucleotide) / len(s) * 100))

