seq = "atctttagtcttcagtgtaaacacgacctccggtccgctcggctcacaactgtacatgcaatgagatgagtgcctgaatgcgaggggtggtgcctgggcgaaccaaccgagcgcttcaccgttttaacgctacggagttgacgcatactgaatctctctcatgaaagtaggtccgtgagtggatcatcccgattcgaggcttcgctgagtacaccaaaaattcgtatccttatgaatgacttaggtcaaagct"

A = 0
T = 0
C = 0
G = 0

for i in seq:
     if i == "a":
         A=A+1
     if i == "t":
         T=T+1
     if i == "g":
         G=G+1
     if i == "c":
         C=C+1
print('Melting temperature is:',4 * ( G + C ) + 2 * ( A + T ),' °C')

