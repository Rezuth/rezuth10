#include <iostream>
#include <string.h>
#include <math.h>

using namespace std;

int main()
{
    char s1[1000],s2[1000];
    int A[100][100],chr;
    double B[100][100],C[100][100],D[100][100];
    int k=0,h,i,j,aux;
    strcpy(s1,"CAGGTTGGAAACGTAATCA");
    strcpy(s2,"GCGATTACGCATGACGTAA");
    cout<<int('A')<<" "<<int('C')<<" "<<int('G')<<" "<<int('T');
    cout<<endl;
        for(j=1;j<=19;j++)
        {
            A[1][j]=int(s1[k]);
            k++;
        }
        k=0;
        for(j=1;j<=19;j++)
        {
            A[2][j]=int(s2[k]);
            k++;
        }
    for(h=1;h<=4;h++)
    {
       if(h==1)
          chr=65;
       if(h==2)
          chr=67;
       if(h==3)
          chr=71;
       if(h==4)
          chr=84;
       k=1;
       for(j=1;j<=10;j++)
       {
           aux=0;
           for(i=1;i<=9;i++)
           {
               if(A[i][j]==chr)
                  aux++;
           }
           B[h][k]=aux;
           k++;
       }
    }

       for(i=1;i<=4;i++)
           for(j=1;j<=9;j++)
           {
               C[i][j]=B[i][j]/10;
           }

      for(i=1;i<=4;i++)
           for(j=1;j<=9;j++)
           {
               D[i][j]=log(C[i][j]/0.25);
           }

    cout<<"Count matrix:"<<endl;
    cout<<endl;

     for(i=1;i<=4;i++)
     {
         for(j=1;j<=9;j++)
            cout<<B[i][j]<<"   ";
         cout<<endl;
     }
    cout<<endl;
    cout<<endl;

    cout<<"Frequence matrix:"<<endl;
    cout<<endl;

    for(i=1;i<=4;i++)
    {
        for(j=1;j<=9;j++)
            cout<<C[i][j]<<"   ";
        cout<<endl;
    }
    cout<<endl;
    cout<<endl;

    cout<<"Likelihood matrix:"<<endl;
    cout<<endl;

    for(i=1;i<=4;i++)
    {
        for(j=1;j<=9;j++)
            cout<<D[i][j]<<"   ";
        cout<<endl;
    }
    cout<<endl;
    cout<<endl;

    return 0;
}
