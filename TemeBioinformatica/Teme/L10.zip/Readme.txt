Parvulescu Valeriu 1241A
Stefan Andrei 1241A