import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from random import randint

seq = "atctttagtcttcagtgtaaacacgacctccggtccgctcggctcacaactgtacatgcaatgagatgagtgcctgaatgcgaggggtggtgcctgggcgaaccaaccgagcgcttcaccgttttaacgctacggagttgacgcatactgaatctctctcatgaaagtaggtccgtgagtggatcatcccgattcgaggcttcgctgagtacaccaaaaattcgtatccttatgaatgacttaggtcaaagct"

A = 0
T = 0
C = 0
G = 0
CG = 0

aProb = []
tProb = []
gProb = []
cProb = []
cgProb = []

for i in range(1, len(seq)):
  sirCrt = seq[0:i]
  for index, x in enumerate((sirCrt), start=0):
      if x == "a":
          A=A+1
      if x == "t":
          T=T+1
      if x == "g":
          G=G+1
      if x == "c":
          C=C+1
          if index > (len(sirCrt) - 2):
            continue
          if sirCrt[index+1] == "g":
              G=G+1
              CG=CG+1  
  aProb.append(A/len(sirCrt)*100)
  A = 0
  tProb.append(T/len(sirCrt)*100)
  T = 0
  cProb.append(C/len(sirCrt)*100)
  C = 0
  gProb.append(G/len(sirCrt)*100)
  G = 0
  cgProb.append(CG/len(sirCrt)*100)
  CG = 0
        
print('a ', aProb[-1])
print('t ', tProb[-1])
print('c ', cProb[-1])
print('g ', gProb[-1])
print('cg', cgProb[-1])

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111)

ax.plot(cgProb)
fig.savefig('graph.png')
