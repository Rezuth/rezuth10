import numpy as numpy
import math

seq1='ACCGTGAAGCCAATAC'

seq2='AGCGTGCAGCCAATAC'

def algorithmNW():
    match=2
    mismatch=-1
    gap=-2
    x_size = len(seq1)
    y_size = len(seq2)
    matrix = numpy.zeros(shape=(y_size + 1, x_size + 1))
    for i in range(x_size + 1):
        matrix[0, i] = gap*i
    for i in range(y_size + 1):
        matrix[i, 0] = gap*i
    for x in range(1, y_size + 1):
        for y in range(1, x_size + 1):
            s = match if seq1[y-1] == seq2[x-1] else mismatch
            d = max(matrix[x-1, y-1] + s, matrix[x-1, y] + gap, matrix[x, y-1] + gap)
            matrix[x, y] = d
    align_b = ''
    align_a = ''
    a = y_size
    b = x_size
    while a >= 1 or b >= 1:
        m = matrix[a, b]
        s = match if seq1[b - 1] == seq2[a - 1] else mismatch
        if m == matrix[a-1, b-1] + s and a >= 1 and b >= 1:
            align_a += seq1[b-1]
            align_b += seq2[a-1]
            a -= 1
            b -= 1
            continue
        if m == matrix[a, b-1] + gap and a >= 1:
            align_a += seq1[b-1]
            align_b += '-'
            b -= 1
            continue
        if m == matrix[a-1, b] + gap and b >= 1:
            align_b += seq2[a-1]
            align_a += '-'
            a -= 1
            continue
    return align_a, align_b

print(algorithmNW())