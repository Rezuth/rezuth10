from matplotlib import pyplot
import numpy as numpy
import math

sequence='CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG'

def plotPattern(a, b, m):
    pyplot.plot(m[0], m[1], marker='o', markersize=8, color="red")
    pyplot.scatter(a[::-1], b[::-1])
    pyplot.show()

def kic(sequence):
    size = len(sequence) - 1
    result = 0
    for index in range(1, size):
        count = 0
        buffer = sequence[index+1:]
        if buffer == '':
            break
        for i in range(1, len(buffer)):
            if buffer[i] == sequence[i]:
                count += 1
        result += count/len(buffer) * 100
    res = numpy.around(result/size, 2)
    return res

def dnaPattern():
    sliding = 30
    size = len(sequence)
    c_count = sequence.count('C')
    g_count = sequence.count('G')
    cg_tot = (c_count + g_count)/size * 100
    cg_tot = numpy.around(cg_tot, 2)
    cg_count = []
    kic_count = []
    for index in range(size - sliding):
        window = sequence[index: index + sliding]
        sw_c = window.count('C')
        sw_g = window.count('G')
        sw_cg = numpy.around(cg_tot/sliding * (sw_c + sw_g), 2)
        cg_count.append(sw_cg)
        kic_count.append(kic(window))
    mean = [numpy.mean(cg_count), numpy.mean(kic_count)]
    plotPattern(cg_count, kic_count, mean)

dnaPattern()