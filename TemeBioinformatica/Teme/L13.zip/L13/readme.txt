Stefan Andrei 1241A
Parvulescu Valeriu 1241A
Negus Cosmin 1241A