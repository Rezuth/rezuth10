#include <iostream>
#include <string.h>
#include <cstdlib>

using namespace std;

int main()
{
    char s[3001],s1[3001],s2[3001],s3[3001],s4[3001],s5[3001],s6[3001],s7[3001],s8[3001],s9[3001],s10[3001];
    strcpy(s,"GAACGCCCATCTAGCGGCTCGCGTCTTGAATGCTCGGTCCCCTTTGTCATTCCGGATAAATCCATTTCCCTCATTCACCAGCTTGCGAAGTCTACATTGGTATATGAATGCGACCTAGAAGAGGGCGCTTAAAATTGGGAGTGGTTGATGCTCTATACTCCATTTGGTTTTTTCGTGCATCACCGCGATAGGCTGACAAGGGTTTAACATTGAATAGCAAGGCACTTCCGGTCTCAATGAAGGGCCGGGAAAGGTACGCGCGTGGTATGGGAGGATCAAGGGGCCAATAGAAAGGCTTCTCCCTCACTCGCTAGGAGGCAAATGCAGAACAATGGTTACTACATCGATACGTGAAACATGTCCAACGGTTGCCCAAAGTGTTAAGTGTCTATCACCCCTAGGGCCGTTTCCCGGATATAAACGCCAGGTTGAATCCGCATTTGAAGCTACCATGGATGAGTCTGGGTCGAGCGCGCCGCATTTATTGCGTGAGTAGGGTCGACCAAGAACCGCTAGATGCGTCGCTGTACAAATAGTTGTCGACAGACCGTCGAGTTTAGAAAATGGTACCAGCATTTTCGGGGGATCTCAATCAAGTATGGATTACGGTGTTTACACTGTCCTGCGGCTACCCATGGCCTGAAATCCAGCTCGTGTCAAGCCATTGCCTCTCCGGGACGCCGCATGAAGTAATACATATACCTTGCACGGGTTCACTGCGGTCCGTTCAGAGTCGACCAAGGACACAATCGAGCTCCGATCCGTATGCTCGACTAACTTGTACCCAACCCCCGGAGCTTGGCAGCTCCTGGGGTATCATGGAGCCTGTGGTTCATCCCGTCGGATATCAAACTTCGTCTTGATAAAGCCCCCCGCTCGGGAGTACCAGAGAAGATGTCTACTGAGTTGTGCGATCCCTGCACTTCAGCTAAGGAAGCTACCAATATTTAGTTTCTGAGTCTCACGACAGACCTCGCGCGTAGATTGCCATGCGTAGAGCTAACGAGCCAGCGGAAAGCGTGAGGCGCTTTTAAGCATGGCGAGTAAGTGATCCAACGCTTCGGATATGACTATATACTTAGGTTCGATCTCGTCCCGAGAATTCTAAGCCTCAACATCTATGAGTTATGAGGTTAGCCGAAAAAGCACGTGGTGGCGCCCACCGACTGTTCCCAGACTGTAGCTCTTTGTTCTGTCAAGGCCCGACCTTCATCGCGGCCGATTCCTTCTGCGGACCATACCGTCCTGATACTTTGGTCATGTTTCCGTTGTAGGAGTGAACCCACTTGCCTTTGCGTCTTAATACCAATGAAAAACCTATGCACTTTGTACAGGGTACCATCGGGATTCTGAACCCTCAGATAGTGGGGATCCCGGGTATAGACCTTTATCTGCGGTCCAACTTAGGCATAAACCTCCATGCTACCTTGTCAGACCCACCCTGCACGAGGTAAATATGGGACGCGTCCGACCTGGCTCCTGGCGTTCTACGCCGCCACGTGTTCGTTAACTGTTGATTGGTAGCACAAAAGTAATACCATGGTCCTTGAAATTCGGCTCAGTTAGTTCGAGCGTAATGTCACAAATGGCGCAGAACGGCAATGAGTGTTTGACACTAGGTGGTGTTCAGTTCGGTAACGGAGAGACTGTGCGGCATACTTAATTATACATTTGAAACGCGCCCAAGTGACGCTAGGCAAGTCAGAGCAGGTTCCCGTGTTAGCTTAAGGGTAAACATACAAGTCGATTGAAGATGGGTAGGGGGCTTCAATTCGTCCAGCACTCTACGGTACCTCCGAGAGCAAGTAGGGCACCCTGTAGTTCGAAGCGGAACTATTTCGTGGGGCGAGCCCACATCGTCTCTTCTGCGGATGACTTAACACGTTAGGGAGGTGGAGTTGATTCGAACGATGGTTATAAATCAAAAAAACGGAACGCTGTCTGGAGGATGAATCTAACGGTGCGTAACTCGATCACTCACTCGCTATTCGAACTGCGCGAAAGTTCCCAGCGCTCATACACTTGGTTCCGAGGCCTGTCCTGATATATGAACCCAAACTAGAGCGGGGCTGTTGACGTTTGGAGTTGAAAAAATCTAATATTCCAATCGGCTTCAACGTGCACCACCGCAGGCGGCTGACGAGGGGCTCACACCGAGAAAGTAGACTGTTGCGCGTTGGGGGTAGCGCCGGCTAACAAAGACGCCTGGTACAGCAGGAGTATCAAACCCGTACAAAGGCAACATCCTCACTTCGGTGAATCGAAGCGCGGCATCAGGGTTACTTTTTGGATACCTGAAACAAAACCCATCGTAGTCCTTAGACTTGGCACACTTACACCTGCAGCGCGCGCATCTGGAAATAGAGGCCAAGTTCGATCCGTACTCCGACGTACGATGCAACAGTGTGGATGTGACGAGCTTCATTTATACCCTTCGCGCGCCGGACCGGCCTCCGCAAGGCGCGGCGGTGCACAAGCAATTGACAACTAACCACCGTGTATTCGTTATGGCATCAGGCAGTTTAAGTCGAGACAATAGGGCTCGCAATACACAGTTTACCGCATCTTGCCCTAACTGACAAACTGTGATCGACCACTAGCCATGCCATTGCCTCTTAGACACCCCGATACAGTGATTATGAAAGGTTTGCGGGGCATGGCTACGACTTGTTCAGCTACGTCCGAGGGCAGAAACTTATCCCCATTTGTATGTTCACCTATCTACTACCCATCCCCGGAGGTTAAGTAGGTTGTGAGATGCGGGAGAGGTTCTCGATCTTCCCGTGGGACGTCAACCTTTCCCTTGATAAAGCATCCCGCTCGGGTATGGCAGTGAGTACGCCTTCTGAATTGTGCTATCCTTCGTCCTTATCAAAGCTTGCTACCAATAATTAGGATTATTGCCTTGCGACAGACTTCCTACTCACACTCCCTCACATTGAGCTACTCGATGGGCGATTAGCTTGACCCGCTCTGTAGGGTCGCGACTACGTGAGCTAG");
    int r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
    cout<<endl;
    cout<<endl;
    cout<<endl;


    int j=0;
    for(int i=1;i<r;i++)
    {
        s1[j]=s[rand()%3000];
        j++;
    }
    s1[j]=NULL;
    cout<<s1;
     cout<<endl;
    cout<<endl;
    cout<<endl;

    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s2[j]=s[rand()%3000];
        j++;
    }
    s2[j]=NULL;
    cout<<s2;
     cout<<endl;
    cout<<endl;
    cout<<endl;

    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s3[j]=s[rand()%3000];
        j++;
    }
    s3[j]=NULL;
    cout<<s3;
     cout<<endl;
    cout<<endl;
    cout<<endl;

    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s4[j]=s[rand()%3000];
        j++;
    }
    s4[j]=NULL;
    cout<<s4;
     cout<<endl;
    cout<<endl;
    cout<<endl;

    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s5[j]=s[rand()%3000];
        j++;
    }
    s5[j]=NULL;
    cout<<s5;
     cout<<endl;
    cout<<endl;
    cout<<endl;

    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s6[j]=s[rand()%3000];
        j++;
    }
    s6[j]=NULL;
    cout<<s6;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s7[j]=s[rand()%3000];
        j++;
    }
    s7[j]=NULL;
    cout<<s7;
     cout<<endl;
    cout<<endl;
    cout<<endl;

    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s8[j]=s[rand()%3000];
        j++;
    }
    s8[j]=NULL;
    cout<<s8;
     cout<<endl;
    cout<<endl;
    cout<<endl;

    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s9[j]=s[rand()%3000];
        j++;
    }
    s9[j]=NULL;
    cout<<s9;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    r =rand()%(3000 - 100)+100;
    cout<<r<<endl;
     cout<<endl;
    cout<<endl;
    cout<<endl;


    j=0;
    for(int i=1;i<r;i++)
    {
        s10[j]=s[rand()%3000];
        j++;
    }
    s10[j]=NULL;
    cout<<s10;
     cout<<endl;
    cout<<endl;
    cout<<endl;

    cout<<"3000bp:"<<endl;
    cout<<endl;

    if(strlen(s1)<=3000&&strlen(s1)>1500)
        cout<<"s1"<<endl;
    if(strlen(s2)<=3000&&strlen(s2)>1500)
        cout<<"s2"<<endl;
    if(strlen(s3)<=3000&&strlen(s3)>1500)
        cout<<"s3"<<endl;
    if(strlen(s4)<=3000&&strlen(s4)>1500)
        cout<<"s4"<<endl;
    if(strlen(s5)<=3000&&strlen(s5)>1500)
        cout<<"s5"<<endl;
    if(strlen(s6)<=3000&&strlen(s6)>1500)
        cout<<"s6"<<endl;
    if(strlen(s7)<=3000&&strlen(s7)>1500)
        cout<<"s7"<<endl;
    if(strlen(s8)<=3000&&strlen(s8)>1500)
        cout<<"s8"<<endl;
    if(strlen(s9)<=3000&&strlen(s9)>1500)
        cout<<"s9"<<endl;
    if(strlen(s10)<=3000&&strlen(s10)>1500)
        cout<<"s10"<<endl;

    cout<<endl;


    cout<<"1500bp:"<<endl;
    cout<<endl;

    if(strlen(s1)<=1500&&strlen(s1)>500)
        cout<<"s1"<<endl;
    if(strlen(s2)<=1500&&strlen(s2)>500)
        cout<<"s2"<<endl;
    if(strlen(s3)<=1500&&strlen(s3)>500)
        cout<<"s3"<<endl;
    if(strlen(s4)<=1500&&strlen(s4)>500)
        cout<<"s4"<<endl;
    if(strlen(s5)<=1500&&strlen(s5)>500)
        cout<<"s5"<<endl;
    if(strlen(s6)<=1500&&strlen(s6)>500)
        cout<<"s6"<<endl;
    if(strlen(s7)<=1500&&strlen(s7)>500)
        cout<<"s7"<<endl;
    if(strlen(s8)<=1500&&strlen(s8)>500)
        cout<<"s8"<<endl;
    if(strlen(s9)<=1500&&strlen(s9)>500)
        cout<<"s9"<<endl;
    if(strlen(s10)<=1500&&strlen(s10)>500)
        cout<<"s10"<<endl;

    cout<<endl;

    cout<<"500bp:"<<endl;
    cout<<endl;

    if(strlen(s1)<=500)
        cout<<"s1"<<endl;
    if(strlen(s2)<=500)
        cout<<"s2"<<endl;
    if(strlen(s3)<=500)
        cout<<"s3"<<endl;
    if(strlen(s4)<=500)
        cout<<"s4"<<endl;
    if(strlen(s5)<=500)
        cout<<"s5"<<endl;
    if(strlen(s6)<=500)
        cout<<"s6"<<endl;
    if(strlen(s7)<=500)
        cout<<"s7"<<endl;
    if(strlen(s8)<=500)
        cout<<"s8"<<endl;
    if(strlen(s9)<=500)
        cout<<"s9"<<endl;
    if(strlen(s10)<=500)
        cout<<"s10"<<endl;

    cout<<endl;

    return 0;
}
